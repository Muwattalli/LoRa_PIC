/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

#if defined(__XC)
    #include <xc.h>         /* XC8 General Include File */
#elif defined(HI_TECH_C)
    #include <htc.h>        /* HiTech General Include File */
#endif

#include <stdint.h>         /* For uint8_t definition */
#include <stdbool.h>        /* For true/false definition */

#include "user.h"

/******************************************************************************/
/* User Functions                                                             */
/******************************************************************************/

/* <Initialize variables in user.h and insert code for user algorithms.> */

void InitApp(void)
{
    /* TODO Initialize User Ports/Peripherals/Project here */

    /* Setup analog functionality and port direction */

       /* Setup analog functionality and port direction */

        ANSELA = 0 ;    // Override default analog at reset !!!!!!!!!!!!!
        TRISAbits.TRISA4 = 0 ;      // RA4 as output (RX enable)
        TRISAbits.TRISA5 = 0 ;      // RA5 as output (TX enable)

        ANSELB = 0 ;    // Override default analog at reset !!!!!!!!!!!!!
        TRISBbits.TRISB4 = 1 ;      // RB4 as input (MISO)
        TRISBbits.TRISB5 = 0 ;      // RB5 as output (unused RX UART)
        TRISBbits.TRISB6 = 0 ;      // RB6 as output (SCK)
        TRISBbits.TRISB7 = 0 ;      // RB7 as output (unused TX UART)

        ANSELC = 0 ;    // Override default analog at reset !!!!!!!!!!!!!
        TRISCbits.TRISC0 = 1 ;      // RC0 as input (pulsante)
        TRISCbits.TRISC1 = 1 ;      // RC1 as input (DIO0)
        TRISCbits.TRISC2 = 0 ;      // RC2 as output (altro pulsante)
        TRISCbits.TRISC3 = 0 ;      // RC3 as output (led verde)
        TRISCbits.TRISC4 = 0 ;      // RC4 as output (led rosso)
        TRISCbits.TRISC5 = 0 ;      // RC5 as output (RESET)
        TRISCbits.TRISC6 = 0 ;      // RC6 as output (SS)
        TRISCbits.TRISC7 = 0 ;      // RC7 as output (MOSI)


    /* Initialize peripherals */

    /* Enable interrupts */
}

